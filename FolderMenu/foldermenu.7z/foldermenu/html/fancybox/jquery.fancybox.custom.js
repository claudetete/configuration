$(document).ready(function() {
	$("a.fancybox").fancybox({
		'zoomOpacity'	: true,
		'overlayShow'	: false,
		'zoomSpeedIn'	: 500,
		'zoomSpeedOut'	: 500
	});
});
